<?php

/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Paynet\PayPage\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class PaymentMethodAvailable implements ObserverInterface
{
    /**
     * payment_method_is_active event handler.
     *
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(Observer $observer)
    {
        $Paynet = new \Paynet\PayPage\Gateway\Http\Client\Api;
        $code = $observer->getEvent()->getMethodInstance()->getCode();

        if ($Paynet::isPaynetPayment($code)) {
            $checkResult = $observer->getEvent()->getResult();

            if ($checkResult->getData('is_available')) {
                $isAllowed = $Paynet::paymentAllowed($code);
                $checkResult->setData('is_available', $isAllowed);
            }
        }
    }
}
